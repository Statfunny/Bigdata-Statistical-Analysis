import requests
import json
import logging   # 어떤 소프트웨어가 실행될 때 발생하는 이벤트를 추적하는 수단, 
import time
from quixstreams import Application

def get_weather_data():
    response = requests.get("https://api.open-meteo.com/v1/forecast", 
                        params={"latitude": 37.45,
                        "longitude":126.78,
                        "current":"temperature_2m",
                        })
    return response.json()

def weather():
    app = Application(broker_address = "localhost:9092")
    
# producer = app.get_producer()
# producer.produce()
# producer.flush()

    with app.get_producer() as producer:
        while True:
            weather = get_weather_data()
            logging.debug("Got weather: %s",weather)  # 상세한 정보
            producer.produce(
                topic = "weather-events",
                key = "Seoul",
                value = json.dumps(weather)
            )
            logging.info("Produced. Sleeping...")  # 예상대로 작동하는지에 대한 확인
            time.sleep(10)
    

if __name__ == "__main__":
    logging.basicConfig(level="DEBUG")  # 모든 메시지가 출력
    weather()


