import json
from quixstreams import Application

def get_weather():
    app = Application(
        broker_address = "localhost:9092",
        consumer_group = "weather_reader",
#        auto_offset_reset = "earliest"
        auto_offset_reset = "latest"
    )

    with app.get_consumer() as consumer:
        consumer.subscribe(["weather-events"])
        while True:
            msg = consumer.poll(1)
            if msg is None:
                continue
            elif msg.error():
                print('Kafka error:', msg.error())
                continue
            #else:
            offset = msg.offset()
            key = msg.key().decode("utf8")
            value = json.loads(msg.value())
            print(f"{offset} {key} {value}")
            consumer.store_offsets(msg)
            
if __name__ == "__main__":
    try:
        get_weather()
    except KeyboardInterrupt:
        pass
