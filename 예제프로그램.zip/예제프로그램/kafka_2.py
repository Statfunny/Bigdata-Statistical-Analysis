import requests
import json
from quixstreams import Application

response = requests.get("https://api.open-meteo.com/v1/forecast", 
                        params={"latitude": 37.45,
                        "longitude":126.78,
                        "current":"temperature_2m",
                        })

weather_data = response.json()

app = Application(broker_address = "localhost:9092")
# producer = app.get_producer()
# producer.produce()
# producer.flush()

with app.get_producer() as producer:
    producer.produce(
        topic = "weather-events",
        key = "Seoul",
        value = json.dumps(weather_data)
    )
    

