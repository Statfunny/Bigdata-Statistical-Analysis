import requests
response = requests.get("https://api.open-meteo.com/v1/forecast", 
                        params={"latitude": 37.45,
                        "longitude":126.78,
                        "current":"temperature_2m",
                        })
print(response.json())


